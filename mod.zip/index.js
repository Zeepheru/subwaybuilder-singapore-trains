(function () {
  window.SubwayBuilderAPI.trains.registerTrainType({
    id: "sin-classic",
    name: "Classic Singapore Train",
    description: "Classic cabbed Singapore MRT train",
    stats: {
      maxSpeed: 19.44, // m/s (≈70 kph)
      maxAcceleration: 0.95,
      maxDeceleration: 1,
      maxLateralAcceleration: 0.9,
      maxCantMm: 160,
      maxCantDeficiencyMm: 135,
      maxSlopePercentage: 5.5,
      maxSpeedLocalStation: 8.5, // m/s (≈30 kph)
      crossoverSpeed: 6.95, // m/s (≈25 kph)
      yardSpeedLimit: 4.47, // m/s (≈15 kph)
      stopTimeSeconds: 30,
      turnaroundTimeSeconds: 60,
      minTurnRadius: 40,
      minStationTurnRadius: 75,
      parallelTrackSpacing: 3.2,
      trackClearance: 1.2,
      minCars: 5,
      maxCars: 5,
      carsPerCarSet: 5,
      capacityPerCar: 158,
      seatsPerCar: 18,
      doorsPerCarPerSide: 3,
      carLength: 15.12,
      trainWidth: 2.4,
      minStationLength: 78,
      maxStationLength: 84,
      carCost: 920_000,
      baseTrackCost: 27_000,
      baseStationCost: 65_000_000,
      trainOperationalCostPerHour: 300,
      carOperationalCostPerHour: 26,
      trackMaintenanceCostPerMeter: 260,
      stationMaintenanceCostPerYear: 200_000,
      tphLimit: 40,
    },
    compatibleTrackTypes: ["heavy-metro", "sin-classic"],
    appearance: {
      color: "#00C4B3",
      roofStyle: "rounded",
      bodyColor: "#AEB0AD",
      couplerWidthMultiplier: 2,
    },
    portalCost: 10_000_000,
    rampCost: 4_000_000,
    allowGradeCrossing: false,
    maxOverpassSpan: 50,
  });
})();
